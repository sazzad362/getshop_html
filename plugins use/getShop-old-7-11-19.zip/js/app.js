// IIFE with jQuery Wrapper
(function($) {
  'use strict';

  /*
   *----------------------------------
   * Document Ready
   *----------------------------------
   */
	$(document).ready(function() {

	    /****************************
	      stellarnav DropDown Menu
	    *****************************/
	    // $('.stellarnav').stellarNav({ position: 'right' });
	    // var gsMagaMenu = $('#gs-maga-menu').innerWidth();
	    // $('#gs-maga-menu .gs-maga ul')
	    // .css("width", gsMagaMenu);



	    /****************************
	      stellarnav DropDown Menu
	    *****************************/
	    // $('.owl-carousel').owlCarousel({
	    //     loop:true,
	    //     margin:0,
	    //     nav:true,
	    //     items:1,
	    //     responsive:{
	    //         0:{
	    //             items:1
	    //         },
	    //         600:{
	    //             items:1
	    //         },
	    //         1000:{
	    //             items:1
	    //         }
	    //     }
	    // })


	    
	});// DOM Ready


}(jQuery)); // IIFE

